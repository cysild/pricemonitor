<?php $__env->startSection('title', 'Listing Page'); ?>
<?php $__env->startSection('content'); ?>
<body id="listing-page" ng-app="mymodule">
	<header>
		<div class="row">
			<div class="container">
				<div class="col-xs-12 col-sm-5 col-md-6 col-lg-6">
					<img src="<?php echo e(url('/')); ?>/images/logo.png" class="img-responsive logo">
				</div>
				<div class="col-xs-6 col-sm-3 col-md-2 col-lg-2">
					<div class="takeaway">
						<a href="#">
			    			<span><img src="<?php echo e(url('/')); ?>/images/takeaway-icon.png"></span>&nbsp;&nbsp;
			    			<span><?php echo e($type); ?></span>
			    		</a>
					</div>
				</div>
				<div class="col-xs-6 col-sm-4 col-md-4 col-lg-4">
					<div class="location">
						<div>
							<p><i class="fa fa-map-marker" aria-hidden="true"></i></p>
						</div>
						<div>
							<select class="form-control" id="shop">
								
								<?php $__currentLoopData = $restratant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									  	<option value="<?php echo e(encrypt($res->id.'_'.session::get('type'))); ?>" 				<?php if($res->id == session::get('rest_id')): ?> selected <?php endif; ?> ><?php echo e(ucfirst($res->name)); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<div id="menu-list">
		<div class="row">
			<div class="container">
				<div class="hidden-xs col-sm-2 col-md-2 col-lg-2 invisible-scrollbar">
					<div class="col1-list">
						<ul class="list">
							<li>Recommended</li>
                       <?php echo $__env->renderEach('frontend.menu', $categories, 'category'); ?> 


						</ul>
					</div>
				</div>
				<div class="col-xs-12 col-sm-5 col-md-5 col-lg-5 invisible-scrollbar">
					<div class="col2-listitems">
						<div id="recommended">
							<h3>Recommended</h3>
							<div class="menuend"></div>
							<div class="row">
							<?php		$rest_id=Session::get('rest_id');
								$recommend=Helper::get_recommend($rest_id);


							 ?>

							    <?php $__currentLoopData = $recommend['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 foodlist-section sc-product-item">
									<div class="menu-items">
										<img src="<?php echo e(url('/')); ?>/images/item/<?php echo e($recommend->image); ?>" class="img-responsive">
										<p data-name="product_name"><?php echo e($recommend->name); ?></p>
										<div class="row">
											<input name="product_price" value="<?php echo e($recommend->price); ?>" type="hidden" />
											<div class="col-xs-8 col-sm-8 col-md-6 col-lg-8">
												<p>&#163; <span id="product_price"><?php echo e($recommend->price); ?></span></p>
											</div>
											<input name="product_id" value="<?php echo e($recommend->id); ?>" type="hidden" />
											<div class="col-xs-4 col-sm-4 col-md-6 col-lg-4">
												<button class="sc-add-to-cart">ADD</button>
											</div>
										</div>
									</div>
								</div>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>



						<div class="foodlist" id="southindian">


<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div id="southindian-dosa">
					<?php if((count($cat->children) > 0) AND ($cat->parent_id > 0)): ?>
								<h3> <?php echo e($cat->name); ?></h3>
								<div class="menuend"></div>
<?php else: ?>
<h2> <?php echo e($cat->name); ?></h2>
 	<?php $item  =  Helper::get_items($cat->id); ?>
	<?php if($item['count'] > 0): ?>

			

								   <?php $__currentLoopData = $item['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										    	  
										    
			<div class="row foodlist-section sc-product-item">
									<div class="col-xs-8 col-sm-8 col-md-9 col-lg-10">
										<p data-name="product_name">   <?php echo e($items['name']); ?></p>
										    <input name="product_price" value="<?php echo e($items['price']); ?>" type="hidden" />
                                            <input name="product_id" value="<?php echo e($items->id); ?>" type="hidden" />
										<p>&#163; <?php echo e($items['price']); ?></p>
									</div>
									<div class="col-xs-4 col-sm-4 col-md-3 col-lg-2">
										<button class="sc-add-to-cart">ADD</button>
									</div>
								</div>


										      
										     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<?php endif; ?>
<?php endif; ?>

<?php if(count($cat->children) > 0): ?>
  <?php $__currentLoopData = $cat->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <?php if((count($cat->children) > 0) AND ($cat->parent_id > 0)): ?>
									 
			
	<?php else: ?>
	<?php $item  =  Helper::get_items($cat->id); ?>
	<?php if($item['count'] > 0): ?>
								<h4><?php echo e($cat->name); ?> - <?php echo e($item['count']); ?></h4>

								   <?php $__currentLoopData = $item['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										    	  
										    
								<div class="row foodlist-section sc-product-item">
									<div class="col-xs-8 col-sm-8 col-md-9 col-lg-10">
										<p data-name="product_name">   <?php echo e($items['name']); ?></p>
										    <input name="product_price" value="<?php echo e($items['price']); ?>" type="hidden" />
                                            <input name="product_id" value="<?php echo e($items->id); ?>" type="hidden" />
										<p>&#163; <?php echo e($items['price']); ?></p>
									</div>
									<div class="col-xs-4 col-sm-4 col-md-3 col-lg-2">
										<button class="sc-add-to-cart">ADD</button>
									</div>
								</div>


										      
										     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<?php endif; ?>
		<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>



						</div>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
					</div>
				</div>
				<div class="hidden-xs col-sm-5 col-md-5 col-lg-5">
					<div class="col3-cart">
						<h3>Cart</h3>
						<form action="<?php echo e(url('/addorders')); ?>" method="POST">
							
						<?php echo e(csrf_field()); ?>

						                    <div id="smartcart"></div>

			</form>
			
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="mobile-menu-button" class="text-center">
		<button type="button" data-toggle="modal" data-target="#menuinmobile"><i class="fa fa-cutlery" aria-hidden="true"></i> Menu</button>
	</div>
	<div id="cart-mobile">
		<div class="row">
			<div>
				<p>1 Item | &#163; 24</p>
			</div>
			<div>
				<p>VIEW CART</p>
			</div>
		</div>
	</div>
	<!-- Modal -->
	<div id="menuinmobile" class="modal fade" role="dialog">
  		<div class="modal-dialog">
    		<!-- Modal content-->
    		<div class="modal-content">
      			<div class="modal-header">
        			<button type="button" class="close" data-dismiss="modal">&times;</button>
        			<h4 class="modal-title">Menu List</h4>
        		</div>
      			<div class="modal-body invisible-scrollbar mobile-menu">
        			<div class="col1-list">
						<ul class="list">
							<li class="active"><a href="#">Recommended</a></li>
							<li><a class="drop-submenu">South Indian</a>
								<ul class="sub-food-menu">
									<li><a href="#southindian-dosa" class="scrollLink">Dosa</a></li>
									<li><a href="#southindian-uttapam" class="scrollLink">Uttapams</a></li>
									<li><a href="#" class="scrollLink">Idlis & Vadas</a></li>
								</ul>
							</li>
							<li><a href="#" class="drop-submenu">Quick Bites</a>
								<ul class="sub-food-menu">
									<li><a href="#" class="scrollLink">Savouries</a></li>
									<li><a href="#" class="scrollLink">Chaats</a></li>
									<li><a href="#" class="scrollLink">Sandwiches</a></li>
								</ul>
							</li>
							<li><a href="#">Soups</a></li>
							<li><a href="#" class="drop-submenu">Chinese</a>
								<ul class="sub-food-menu">
									<li><a href="#" class="scrollLink">Veg Starters</a></li>
									<li><a href="#" class="scrollLink">Veg Main Course</a></li>
									<li><a href="#" class="scrollLink">Fried Rice</a></li>
									<li><a href="#" class="scrollLink">Noodles</a></li>
								</ul>
							</li>
							<li><a href="#" class="drop-submenu">Desserts</a>
								<ul class="sub-food-menu">
									<li><a href="#" class="scrollLink">Fresh Juices</a></li>
									<li><a href="#" class="scrollLink">Shakes</a></li>
								</ul>
							</li>
						</ul>
					</div>
     			 </div>
      			<div class="modal-footer">
        			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      			</div>
    		</div>
  		</div>
	</div>
</body>
<?php echo $__env->make('frontend.complete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>