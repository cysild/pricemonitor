<!-- Modal -->
<div id="complete" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Complete Order</h4>
      </div>
      <div class="modal-body">
                   <div class="center-block msg">
                    <div class="alert alert-success" style="display:none"></div>
                    <div class="alert alert-danger" style="display:none"></div>
                  </div>

                  <div class="form-group">

                    <label for="name_en" class=" col-md-1"> Name :</label>
                    <div class=" col-md-5">
                       <input type="text" class="form-control" name="name" value="" placeholder="" required>
                    </div>   

                         <label for="name_en" class=" col-md-1"> Phone:</label>
                    <div class=" col-md-5">
                    <input type="text" class="form-control" name="phone" value="" placeholder="Chinese,Soups,..." required>
                    </div>   
                    <p>total:<span class="tot"></span></p>


                    <?php echo e(csrf_field()); ?>

                </div>



        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>