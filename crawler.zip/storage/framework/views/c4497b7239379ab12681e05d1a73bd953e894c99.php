<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('recommend.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>





<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>

<style type="text/css">
@media (min-width: 768px){
.modal-dialog {
    width: 600px;
    margin: 30px auto;
}
}
.one div{
  display: table-cell;
  padding-left: 10px;
}
.one div:first-child{
  padding-left: 0px;
}
</style>
        <?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('/admin')); ?>/vendor/ckeditor/ckeditor.js"></script>
<script src="<?php echo e(url('/admin')); ?>/vendor/ckeditor/adapters/jquery.js"></script>
<script src="<?php echo e(url('/admin')); ?>/js/bootbox.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(url('/vendor/adminlte/vendor/toggle')); ?>/bootstrap-toggle.min.css">
<script src="<?php echo e(url('/vendor/adminlte/vendor/toggle')); ?>/bootstrap-toggle.min.js"></script>
<script>

  $('#prod').attr('multiple', 'multiple');
    $("#prod option")[0].remove();

     $('.product').select2({
      width: '100%',
      multiple:true,
      allowClear: true,
        placeholder: 'Select Items',
        ajax: {
          url: "<?php echo e(url('/admin')); ?>/item/list",
          dataType: 'json',
          delay: 250,
            initSelection: true, 

          processResults: function (data) {
            return {
              results:  $.map(data, function (item) {

                    if(item== ''){
                      return null;
                    }
                    return {
                        text: item.name,
                        id: item.id,
                    }
                })
            };
          },
          cache: false
        }
      });


    $(document).ready(function(){  
       var Select = $('.product');

       $(".product").empty().trigger('change');

    var xurl="<?php echo e(url('admin/item/recommend/list/get')); ?>";      
     $.ajax({
              type:'GET',
              url:xurl,
              success: function(data)
              {  


          if(!data.error){

     $.each(data, function(key, value){



         var option = new Option(value.name,value.id, true, true);
                Select.append(option).trigger('change');
                Select.trigger({
                    type: 'select2:select',
                    params: {
                        data: data
                    }
                });


              });
   }

              }
            });
  });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>