<?php if((count($category->children) > 0) AND ($category->parent_id > 0)): ?>

    <li><a href="#<?php echo e($category->name); ?> "><?php echo e($category->name); ?> <i class="fa fa-chevron-right"></i></a>

<?php else: ?>

    <li><a href="#<?php echo e($category->name); ?>" class="submenu"><?php echo e($category->name); ?></a> 

<?php endif; ?>

    <?php if(count($category->children) > 0): ?>

        <ul class="submenu-items">

        <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 <?php if($category->status == 1): ?>
            <?php echo $__env->make('frontend.menu', $category, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

    <?php endif; ?>

    </li>