<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('client.settingform', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>

<style type="text/css">
@media (min-width: 768px){
.modal-dialog {
    width: 500px;
    margin: 30px auto;
}
}
</style>
        <?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<script src="<?php echo e(url('/admin')); ?>/js/bootbox.min.js"></script>
<script src="<?php echo e(url('/admin')); ?>/vendor/ckeditor/ckeditor.js"></script>
<script src="<?php echo e(url('/admin')); ?>/vendor/ckeditor/adapters/jquery.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(url('/vendor/adminlte/vendor/toggle')); ?>/bootstrap-toggle.min.css">
<script src="<?php echo e(url('/vendor/adminlte/vendor/toggle')); ?>/bootstrap-toggle.min.js"></script>

<script>
    $(document).ready(function(){


    	 $("[name='statuscheck']").change(function() {
          if($(this).is(":checked")){
              $("[name='status']").val(1);



          }
          if($(this).is(":not(:checked)")){
              $("[name='status']").val(0);
          }


       });

    <?php	 if($shop->is_enable == 1){ ?>
                  var statuss = "on";
                  <?php  }
                 else
                {   ?>

                  var statuss = "off";
         <?php       } ?>
           $('[name=statuscheck]').bootstrapToggle(statuss);
});
    
 </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>