<?php $__env->startSection('title', 'Listing Page'); ?>
<?php $__env->startSection('content'); ?>
<body id="listing-page" ng-app="mymodule">
	<span id="response"></span>
	<header>
		<div class="row">
			<div class="container">
				<div class="col-xs-12 col-sm-5 col-md-6 col-lg-6">
					<img src="<?php echo e(url('/')); ?>/images/logo.png" class="img-responsive logo">
				</div>
				<div class="col-xs-6 col-sm-3 col-md-2 col-lg-2">
					<div class="takeaway">
						<a href="#">
			    			<span><img src="<?php echo e(url('/')); ?>/images/takeaway-icon.png"></span>&nbsp;&nbsp;
			    			<span><?php echo e($type); ?></span>
			    		</a>
					</div>
				</div>
				<div class="col-xs-6 col-sm-4 col-md-4 col-lg-4">
					<div class="location">
						<div>
							<p><i class="fa fa-map-marker" aria-hidden="true"></i></p>
						</div>
						<div>
							<select class="form-control" id="shop">
								<?php $__currentLoopData = $restratant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									  	<option value="<?php echo e(encrypt($res->id.'_'.session::get('type'))); ?>" 				<?php if($res->id == session::get('rest_id')): ?> selected <?php endif; ?> ><?php echo e(ucfirst($res->name)); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<div id="menu-list">
		<div class="row">
			<div class="container">
				<div class="hidden-xs hidden-sm col-md-2 col-lg-2 invisible-scrollbar"> 
					<div class="col1-list">
						<div class="desktop-menulist">
							<ul class="list">
								<li><a href="#recommended">Recommended</a></li>
	                       		<?php echo $__env->renderEach('frontend.menu', $categories, 'category'); ?> 
								<?php $type=Session::get('type');  ?>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-5 col-lg-5 invisible-scrollbar">
					<div class="col2-listitems">
						<?php if($type == 't'): ?>
							<div id="recommended">
								<h3>Recommended</h3>
								<div class="menuend"></div>
								<div class="row">
									<?php 
										$rest_id=Session::get('rest_id');
										$recommend=Helper::get_recommend($rest_id);
									?>
									<?php if($recommend['items']): ?>
							    		<?php $__currentLoopData = $recommend['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							 				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 foodlist-section sc-product-item">
												<div class="menu-items">
													<img src="<?php echo e(Helper::product_image($recommend->image)); ?>" class="img-responsive">
													<h4 data-name="product_name"><?php echo e($recommend->name); ?></h4>
													<div class="row">
														<input name="product_price" value="<?php echo e($recommend->price); ?>" type="hidden" />
														<div class="col-xs-8 col-sm-8 col-md-4 col-lg-6">
															<p>&#163; <span id="product_price"><?php echo e($recommend->price); ?></span></p>
														</div>
														<input name="product_id" value="<?php echo e($recommend->id); ?>" type="hidden" />
														<div class="col-xs-4 col-sm-4 col-md-8 col-lg-6">
															<button class="sc-add-to-cart">+ ADD</button>
														</div>
													</div>
												</div>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>
							<?php endif; ?>
						<?php endif; ?>
						<div class="foodlist" >
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div id="<?php echo e($cat->name); ?>" class="foodlist-items">
									<?php if((count($cat->children) > 0) AND ($cat->parent_id > 0)): ?>
										<div class="head">
											<h3> <?php echo e($cat->name); ?></h3>
											<p><?php echo e(count($cat->name)); ?> ITEM</p>
										</div>
									<?php else: ?>
										<div class="head">
											<h3> <?php echo e($cat->name); ?></h3>
											<p><?php echo e(count($cat->name)); ?> ITEMS</p>
										</div>
 										<?php $item  =  Helper::get_items($cat->id); ?>
										<?php if($item['count'] > 0): ?>
								   			<?php $__currentLoopData = $item['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($type== 't'): ?>		 					    
													<div class="row foodlist-section">
														<div class="sc-product-item">
															<div class="col-xs-8 col-sm-8 col-md-9 col-lg-9">
																<h4 data-name="product_name">   <?php echo e($items['name']); ?></h4>
																    <input name="product_price" value="<?php echo e($items['price']); ?>" type="hidden" />
						                                            <input name="product_id" value="<?php echo e($items->id); ?>" type="hidden" />
																<p>&pound; <?php echo e($items['price']); ?></p>
															</div>
															<div class="col-xs-4 col-sm-4 col-md-3 col-lg-3">
																<button class="sc-add-to-cart">+ ADD</button>
															</div>
														</div>
													</div>
												<?php else: ?>
										<div class="row foodlist-section uit">
											<div class="sc-product-item">
												<div class="col-xs-8 col-sm-8 col-md-9 col-lg-9">
													<p data-name="product_name">   <?php echo e($items['name']); ?></p>
													    <input name="product_price" value="<?php echo e($items['points']); ?>" type="hidden" />
			                                            <input name="product_id" id="pid" value="<?php echo e($items->id); ?>" type="hidden" />
													<p>points:<?php echo e($items['points']); ?></p>
												</div>
												<div class="col-xs-4 col-sm-4 col-md-3 col-lg-3">
													<button class="add-item sc-add-to-cart">+ ADD</button>
												</div>
											</div>
										</div>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						<?php endif; ?>
									<?php if(count($cat->children) > 0): ?>
  										<?php $__currentLoopData = $cat->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   											<?php if((count($cat->children) > 0) AND ($cat->parent_id > 0)): ?>											
									<?php else: ?>
										<?php $item  =  Helper::get_items($cat->id); ?>
										<?php if($item['count'] > 0): ?>
											<h4><?php echo e($cat->name); ?> - <?php echo e($item['count']); ?></h4>
								   			<?php $__currentLoopData = $item['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($type== 't'): ?>		    	  
													<div class="row foodlist-section">
														<div class="sc-product-item">
															<div class="col-xs-8 col-sm-8 col-md-9 col-lg-9">
																<p data-name="product_name">   <?php echo e($items['name']); ?></p>
											    				<input name="product_price" value="<?php echo e($items['price']); ?>" type="hidden" />
	                                            				<input name="product_id" value="<?php echo e($items->id); ?>" type="hidden" />
																<p>&pound; <?php echo e($items['price']); ?></p>
															</div>
															<div class="col-xs-4 col-sm-4 col-md-3 col-lg-3">
																<button class="sc-add-to-cart">+ ADD</button>
															</div>
														</div>
													</div>
												<?php else: ?>
											<div class="row foodlist-section uit">
											<div class="sc-product-item">
									<div class="col-xs-8 col-sm-8 col-md-9 col-lg-9">
										<p data-name="product_name">   <?php echo e($items['name']); ?></p>
										    <input name="product_price" value="<?php echo e($items['points']); ?>" type="hidden" />
                                            <input name="product_id" id="pid" value="<?php echo e($items->id); ?>" type="hidden" />
										<p>points:<?php echo e($items['points']); ?></p>
									</div>
									<div class="col-xs-4 col-sm-4 col-md-3 col-lg-3">
										<button class="add-item sc-add-to-cart">+ ADD</button>
									</div>
								</div>
								</div>



								<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-6 col-md-5 col-lg-5 " id ="mobilecart">
				<?php if($type=='t'): ?>
					<div class="col3-cart invisible-scrollbar">
						<h3>Cart</h3>
						<form action="<?php echo e(url('/addorders')); ?>" method="POST">	
							<?php echo e(csrf_field()); ?>

		                    <div id="smartcart">
		                    	<div id="cart-mobile">
									<div class="row">
										<div class="col-xs-6 hidden-sm hidden-md hidden-lg">
											<div class="sc-cart-heading">
												<p><span class="sc-cart-count"></span> Item | <span class="sc-cart-subtotal"></span></p>
											</div>
										</div>
										<div class="mobileviewcartbtn">
											<div class="col-xs-6 hidden-sm hidden-md hidden-lg">
												<p class="text-right"><a href="#mobilecart">VIEW CART</a></p>
											</div>
										</div>
									</div>
								</div>
		                    </div>
		                    
						</form>
					</div>
				<?php else: ?>
				<div class="col3-cart invisible-scrollbar">
						<h3>Cart</h3>
						<form action="<?php echo e(url('/addorders')); ?>" method="POST">	
							<?php echo e(csrf_field()); ?>

		                    <div id="takeaway">
		                    	<div id="cart-mobile">
									<div class="row">
										<div class="col-xs-6 hidden-sm hidden-md hidden-lg">
											<div class="sc-cart-heading">
												<p><span class="sc-cart-count"></span> Item | <span class="sc-cart-subtotal"></span> Points</p>
											</div>
										</div>
										<div class="mobileviewcartbtn">
											<div class="col-xs-6 hidden-sm hidden-md hidden-lg">
												<p class="text-right"><a href="#mobilecart">VIEW CART</a></p>
											</div>
										</div>
									</div>
								</div>
		                    </div>
		                    
						</form>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
	</div>
	<div id="mobile-menu-button" class="text-center">
		<button type="button" data-toggle="modal" data-target="#menuinmobile"><i class="fa fa-cutlery" aria-hidden="true"></i> Menu</button>
	</div>
	
	<!-- Modal -->
	<div id="menuinmobile" class="modal fade" role="dialog">
  		<div class="modal-dialog">
    		<!-- Modal content-->
    		<div class="modal-content">
      			<div class="modal-header">
        			<button type="button" class="close" data-dismiss="modal">&times;</button>
        			<h4 class="modal-title">Menu List</h4>
        		</div>
      			<div class="modal-body invisible-scrollbar mobile-menu">
        			<div class="col1-list">
						<ul class="list">
							<li><a href="#recommended">Recommended</a></li>
                       		<?php echo $__env->renderEach('frontend.menu', $categories, 'category'); ?> 
							<?php $type=Session::get('type');  ?>
						</ul>
					</div>
     			 </div>
      			<div class="modal-footer">
        			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      			</div>
    		</div>
  		</div>
	</div>
	
</body>
<?php echo $__env->make('frontend.complete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>








<?php $__env->startSection('js'); ?>

    <script src="<?php echo e(url('/')); ?>/js/jquery.smartCart.js" type="text/javascript"></script>
    <script src="<?php echo e(url('/')); ?>/js/takeaway.js" type="text/javascript"></script>
            <link rel="stylesheet" href="<?php echo e(url('/css')); ?>/bootstrap-datepicker.css">

      <script src="<?php echo e(url('/')); ?>/js/bootstrap-datepicker.js" type="text/javascript"></script>
    <script type="text/javascript">

  
        $(document).ready(function(){
            // Initialize Smart Cart    	
getmembers();

var dateToday = new Date();

// var day = new Date();
// console.log(day); // Apr 30 2000

// var nextDay = new Date(day);


// var vv = nextDay.setDate(day.getDate()+1);

// $('.datepicker').datepicker({ 'startDate': vv,
// 	   format: 'yyyy-mm-dd',


//  }


//  );

    $(".datepicker").datepicker({
        dateFormat: "dd/mm/yy",
        changeMonth: true,
        changeYear: true,
        numberOfMonths: 2,
        startDate: dateToday,
	   format: 'yyyy-mm-dd',
       
    });

    $(".datepicker").datepicker("setDate", "2");


<?php if($type == 'p'): ?>
      $('#takeaway').Takeaway({
  				<?php if(Session::has('cart')): ?>
            	cart:  <?php echo Session::get('cart'); ?> ,
            	<?php endif; ?>

       });

            <?php else: ?>

      $('#smartcart').smartCart({
  				<?php if(Session::has('cart')): ?>
            	cart:  <?php echo Session::get('cart'); ?> ,
            	<?php endif; ?>
            });
              
   

            <?php endif; ?>
		});

		

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>